package com.example.vt6002cem;


import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    private LocationListener locationListener;
    private LocationManager locationManager;

    private final long MIN_TIME = 1000; // 1 second
    private final long MIN_DIST = 5; // 5 Meters

    private LatLng latLng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
// Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PackageManager.PERMISSION_GRANTED);
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, PackageManager.PERMISSION_GRANTED);

    }
    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {

                try {
                    latLng = new LatLng(location.getLatitude(), location.getLongitude());
                    // mMap.addMarker(new MarkerOptions().position(latLng).title("My Position"));
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng,15), 4000, null);
                    // mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,15));
                }
                catch (SecurityException e){
                    e.printStackTrace();
                }

            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

            }
        };
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MIN_TIME, MIN_DIST, locationListener);
        LatLng redHouse = new LatLng(22.377797383845685, 113.95968497588291);
        LatLng History = new LatLng(22.301873101928635, 114.1773523396193);
        LatLng TSL = new LatLng(22.448828014430546, 114.00618684381335);
        LatLng SYSM = new LatLng(22.282044595891595, 114.15088994780022);
        LatLng MMT = new LatLng(22.283987491589954, 114.15019819111505);
        LatLng STUM = new LatLng(22.37219144871462, 114.12032032455556);
        LatLng HKHM = new LatLng(22.377184444214198, 114.18535292031294);
        LatLng FHMTW = new LatLng(22.301873101928635, 114.1773523396193);
        LatLng WCHT = new LatLng(22.282044595891595, 114.15088994780022);
        LatLng HKHS = new LatLng(22.273964255871466, 114.17408425181694);
        LatLng HKNE = new LatLng(22.28341347853904, 114.15097288455422);
        LatLng HKRM = new LatLng(22.44759385908047, 114.16434141551757);
        LatLng HKHDC = new LatLng(22.299314697557456, 114.16982911400997);
        LatLng HKMM = new LatLng(22.286876286616604, 114.16208449184465);
        LatLng HKPRB = new LatLng(22.312585758372215, 114.22962599265755);
        LatLng LTU = new LatLng(22.337848966903547, 114.16005289513065);
        LatLng HKMCD = new LatLng(22.281819836058304, 114.23564253089273);
        LatLng SYFM = new LatLng(22.392894779880915, 114.32139445498133);
        mMap.addMarker(new MarkerOptions().position(redHouse).title("Red House"));
        mMap.addMarker(new MarkerOptions().position(SYSM).title("Dr Sun Yat-sen Museum"));
        mMap.addMarker(new MarkerOptions().position(TSL).title("Tsui Sing Lau"));
        mMap.addMarker(new MarkerOptions().position(History).title("History Museum"));
        mMap.addMarker(new MarkerOptions().position(MMT).title("Man Mo Temple"));
        mMap.addMarker(new MarkerOptions().position(STUM).title("Sam Tung Uk Museum"));
        mMap.addMarker(new MarkerOptions().position(HKHM).title("Hong Kong Heritage Museum"));
        mMap.addMarker(new MarkerOptions().position(FHMTW).title("Flagstaff House Museum of Tea Ware"));
        mMap.addMarker(new MarkerOptions().position(WCHT).title("The Wan Chai Heritage Trail"));
        mMap.addMarker(new MarkerOptions().position(HKHS).title("Hong Kong House of Stories"));
        mMap.addMarker(new MarkerOptions().position(HKNE).title("Hong Kong News-Expo"));
        mMap.addMarker(new MarkerOptions().position(HKRM).title("Hong Kong Railway Museum"));
        mMap.addMarker(new MarkerOptions().position(HKHDC).title("Hong Kong Heritage Discovery Centre"));
        mMap.addMarker(new MarkerOptions().position(HKMM).title("Hong Kong Maritime Museum"));
        mMap.addMarker(new MarkerOptions().position(HKPRB).title("Hong Kong Public Records Building"));
        mMap.addMarker(new MarkerOptions().position(LTU).title("Lee Cheng Uk Han Tomb Museum"));
        mMap.addMarker(new MarkerOptions().position(HKMCD).title("Hong Kong Museum of Coastal Defence"));
        mMap.addMarker(new MarkerOptions().position(SYFM).title("Sheung Yiu Folk Museum"));

    }
}
