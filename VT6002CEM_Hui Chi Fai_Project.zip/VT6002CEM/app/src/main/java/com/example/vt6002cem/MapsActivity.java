package com.example.vt6002cem;


import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.example.vt6002cem.databinding.ActivityMapsBinding;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {


    private static GoogleMap mMaps;
    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    protected Location mLastLocation;
    protected GoogleApiClient mGoogleApiClient;
    public double lat;
    public double lng;
    public LocationManager lm;
    private LatLng current;


    private LocationListener ll = new LocationListener() {
        @Override
        public void onLocationChanged(final Location location) {
            //your code here
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        lm = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        // provider = lm.getProvider(LocationManager.GPS_PROVIDER);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        // lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        // LocationProvider provider = locationManager.getProvider(LocationManager.GPS_PROVIDER);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }
        // Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        // lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5, 5, ll);
        // receiver = new LocationBroadcastReceiver();
        onConnected(savedInstanceState);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */


    @Override
    public void onConnected(@Nullable Bundle bundle) {
        super.onStart();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }

        // mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        // lat = mLastLocation.getLatitude();
        // lng = mLastLocation.getLongitude();
        // lm = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        // LocationProvider provider = lm.getProvider(LocationManager.GPS_PROVIDER);
        // LatLng current = new LatLng(lat, lng);
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }
        // mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        // lat = mLastLocation.getLatitude();
        // lng = mLastLocation.getLongitude();
        lat = 22.39064512014432;
        lng = 114.19806813028254;
        current = new LatLng(lat,lng);
        LatLng redHouse = new LatLng(22.377797383845685, 113.95968497588291);
        LatLng History = new LatLng(22.301873101928635, 114.1773523396193);
        LatLng TSL = new LatLng(22.448828014430546, 114.00618684381335);
        LatLng SYSM = new LatLng(22.282044595891595, 114.15088994780022);
        LatLng MMT = new LatLng(22.283987491589954, 114.15019819111505);
        LatLng STUM = new LatLng(22.37219144871462, 114.12032032455556);
        LatLng HKHM = new LatLng(22.377184444214198, 114.18535292031294);
        LatLng FHMTW = new LatLng(22.301873101928635, 114.1773523396193);
        LatLng WCHT = new LatLng(22.282044595891595, 114.15088994780022);
        LatLng HKHS = new LatLng(22.273964255871466, 114.17408425181694);
        LatLng HKNE = new LatLng(22.28341347853904, 114.15097288455422);
        LatLng HKRM = new LatLng(22.44759385908047, 114.16434141551757);
        LatLng HKHDC = new LatLng(22.299314697557456, 114.16982911400997);
        LatLng HKMM = new LatLng(22.286876286616604, 114.16208449184465);
        LatLng HKPRB = new LatLng(22.312585758372215, 114.22962599265755);
        LatLng LTU = new LatLng(22.337848966903547, 114.16005289513065);
        mMap.addMarker(new MarkerOptions().position(redHouse).title("Red House"));
        mMap.addMarker(new MarkerOptions().position(SYSM).title("Dr Sun Yat-sen Museum"));
        mMap.addMarker(new MarkerOptions().position(TSL).title("Tsui Sing Lau"));
        mMap.addMarker(new MarkerOptions().position(History).title("History Museum"));
        mMap.addMarker(new MarkerOptions().position(MMT).title("Man Mo Temple"));
        mMap.addMarker(new MarkerOptions().position(STUM).title("Sam Tung Uk Museum"));
        mMap.addMarker(new MarkerOptions().position(HKHM).title("Hong Kong Heritage Museum"));
        mMap.addMarker(new MarkerOptions().position(FHMTW).title("Flagstaff House Museum of Tea Ware"));
        mMap.addMarker(new MarkerOptions().position(WCHT).title("The Wan Chai Heritage Trail"));
        mMap.addMarker(new MarkerOptions().position(HKHS).title("Hong Kong House of Stories"));
        mMap.addMarker(new MarkerOptions().position(HKNE).title("Hong Kong News-Expo"));
        mMap.addMarker(new MarkerOptions().position(HKRM).title("Hong Kong Railway Museum"));
        mMap.addMarker(new MarkerOptions().position(HKHDC).title("Hong Kong Heritage Discovery Centre"));
        mMap.addMarker(new MarkerOptions().position(HKMM).title("Hong Kong Maritime Museum"));
        mMap.addMarker(new MarkerOptions().position(HKPRB).title("Hong Kong Public Records Building"));
        mMap.addMarker(new MarkerOptions().position(LTU).title("Lee Cheng Uk Han Tomb Museum"));
        mMap.addMarker(new MarkerOptions().position(current).title("You are here"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(current,11.5f));
    }
}
